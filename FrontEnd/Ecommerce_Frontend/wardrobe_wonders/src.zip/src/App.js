import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.css"
import {Routes,Route} from 'react-router-dom'
import Header from "./components/Header";
import Footer from './components/Footer';
import MainNavBar from './components/MainNavBar';
import Login from './pages/Login';
import Register from './pages/Register';
import HomeComponent from './pages/Homecomponent';
import AdminComponent from './pages/AdminComponent';

function App() {
  return (
    <div className="App">
        <Header></Header>
      <MainNavBar></MainNavBar>
      <Routes>
          <Route path="/home" element={<HomeComponent/>}></Route>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin" element={<AdminComponent />} />
      </Routes>
      <Footer></Footer>
    </div>
  );
}

export default App;
