import React from 'react'
import "./Header.css"
export default function Footer() {
  return (
    <div>
       <h3 className="footer">&copy; copyrights reserved</h3>
    </div>
  )
}
// import React from 'react';
// //import '../style/Footer.css'; // Import the CSS file

// function Footer() {
//   return (
//     <footer className="footer">
//       <div className="footer-content">
//         <div className="footer-section about">
//           <h2>KunSavi FashionFusion</h2>
//           <p>Your one-stop shop for the latest in fashion trends and timeless classics. We blend tradition with modernity to bring you the best in fashion.</p>
//         </div>
//         <div className="footer-section contact">
//           <h3>Contact Us</h3>
//           <p>Email: support@kunsavifashionfusion.com</p>
//           <p>Phone: +91 7368738712</p>
//           <p>Address: KunSavi FashionFusion, Pune</p>
//         </div>
//       </div>
//       <div className="footer-bottom">
//         &copy; 2024 KunSavi FashionFusion | All Rights Reserved
//       </div>
//     </footer>
//   );
// }

// export default Footer;