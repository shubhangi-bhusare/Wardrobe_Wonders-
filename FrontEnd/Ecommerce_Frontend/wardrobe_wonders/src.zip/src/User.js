class User{
    constructor(name,email,password,role,mobileNumber,address,zipcode,city,state) {
    this.name = name;
    this.email = email;
    this.password = password;
    this.role = role;
    this.mobileNumber = mobileNumber;
    this.address = address;
    this.zipcode = zipcode;
    this.city = city;
    this.state = state;
}
}
export default User;