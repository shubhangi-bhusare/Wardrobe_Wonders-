//import Product from '../Product';
import axios from 'axios';
import httpClient from '../http_common';
//var baseUrl="http://localhost:3002/products"
var baseUrl="http://localhost:7070/products"
// class ProductService{
//     constructor(){
//     }
//     getAllProducts(){
//         return axios.get(baseUrl + "/getProducts");
//     }
//     getById(id){
//         return axios.get(baseUrl+"/getProductById/"+id);
//     }

//     addProduct(product){
//         //add product at the end of the array
//         //var headers={"content-type":"application/json",Atherization:"barer+<token>"}
//         var myheader={"content-type":"application/json"}
//         return axios.post(baseUrl+"/addProduct"+product,{headers:myheader})
         
//     }
//     updateproduct(product){
//         var myheader={"content-type":"application/json"}
//        return axios.put(baseUrl+"/updateProduct"+product,{headers:myheader})

//     }
//     deleteProduct(id){
//         return axios.delete(baseUrl+"/deleteProduct/"+id)
//     }
// }

// export default new ProductService();
const addProduct=(data) => {
    return httpClient.post('products/addProduct',data)
};
const deleteProduct = (id) => {
    return httpClient.delete(`products/deleteProduct/${id}`);
};
const updateProduct=(data)=>{
    return httpClient.put('products/updateProduct',data);
}
const getAllproducts=()=>{
    return httpClient.get('products/getProducts')
}
export default {addProduct,deleteProduct,updateProduct,getAllproducts};