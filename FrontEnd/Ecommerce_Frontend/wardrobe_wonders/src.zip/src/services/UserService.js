//import axios from 'axios';
import httpClient from '../http_common';
//var baseUrl="http://localhost:3002/products"
var baseUrl="http://localhost:7070/users"
// class UserService{
//     constructor(){
//     }
    
    // getAllUsers(){
    //     return axios.get(baseUrl+"/getUsers");
    // }
    // getById(id){
    //     return axios.get(baseUrl+"/getById/"+id);
    // }

    // addUser(formData){
    //     //add product at the end of the array
    //     //var headers={"content-type":"application/json",Atherization:"barer+<token>"}
    //     var myheader={"content-type":"application/json"}
    //     return axios.post(baseUrl+"/addUser"+formData,{headers:myheader})
         
    // }
    // updateUser(user){
    //     var myheader={"content-type":"application/json"}
    //    return axios.put(baseUrl+"/updateUser"+user,{headers:myheader})

    // }
    // deleteUser(id){
    //     return axios.delete(baseUrl+"/deleteUser/"+id)
    // }
    const addUser=(data) => {
        return httpClient.post('users/addUser',data)
    };
    const deleteUser = (id) => {
        return httpClient.delete(`users/deleteUser/${id}`);
    };
    
    
    
// }
// const userServiceInstance = new UserService();
// export default userServiceInstance;
//export default new UserService();
export default {addUser,deleteUser};