import React, { useState, useEffect } from 'react';
import ProductService from '../services/ProductService';
import '../Style/ShowProductImages.css';
import kidGirl1 from '../Images/kidGirl1.jpg';
function ShowProductImages() {
  const [products, setProducts] = useState([]);

  // Fetch all products when the component mounts
  useEffect(() => {
    ProductService.getAllproducts()
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
      });
  }, []);

  // Function to map product to image
  const getProductImage = (index) => {
    const images = [
      require('../Images/menShirt1.webp').default,
      require('../Images/menDress1.jpg').default,
      require('../Images/menDress2.jpg').default,
      require('../Images/menShirt1.webp').default,
      require('../Images/womenDress1.jpg').default,
      require('../Images/womenDress2.jpg').default,
      require('../Images/saree1.jpg').default,
    ];

    // Use index to get corresponding image, fallback to first image if out of range
    return images[index % images.length];
  };

  return (
    <div className="product-gallery">
      {products.length > 0 ? (
        products.map((product, index) => (
          <div key={product.id} className="product-card">
            <img
              src={getProductImage(index)}
              alt={product.pname}
              className="product-image"
            />
            <h3>{product.pname}</h3>
            <p>{product.description}</p>
            <p>Price: ${product.price}</p>
            <p>Stock: {product.stock}</p>
          </div>
        ))
      ) : (
        <p>No products available</p>
      )}
    </div>
  );
}

export default ShowProductImages;
