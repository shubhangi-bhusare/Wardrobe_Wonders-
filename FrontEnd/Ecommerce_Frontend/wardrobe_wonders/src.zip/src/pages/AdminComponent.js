
import "bootstrap/dist/css/bootstrap.css"
import {Routes,Route} from 'react-router-dom'
import AdminNavBar from "./AdminNavBar";
import AddProductForm from "../AdminFunctionalityComponent/AddProductForm";
import DeleteUserForm from "../AdminFunctionalityComponent/DeleteUserForm";
import DeleteProductForm from "../AdminFunctionalityComponent/DeleteProductForm";
import '../Style/AdminComponent.css';
import UpdateProductForm from "../AdminFunctionalityComponent/UpdateProductForm";
import ShowAllProducts from "../AdminFunctionalityComponent/ShowAllProducts";
import ShowProductImages from "../AdminFunctionalityComponent/ShowProductImages";
function AdminComponent() {
  return (
    <div className="adm">
        <AdminNavBar></AdminNavBar>
      <Routes>
          <Route path="/deleteuser" element={<DeleteUserForm/>}></Route>
          <Route path="/addproduct" element={<AddProductForm />} />
          <Route path="/updateproduct" element={<UpdateProductForm />} />
          <Route path="/deleteproduct" element={<DeleteProductForm />} />
          <Route path="/getAllproduct" element={<ShowAllProducts />} />
          <Route path="/getAllproductImages" element={<ShowProductImages />} />
          
      </Routes>
    </div>
  );
}

export default AdminComponent;
