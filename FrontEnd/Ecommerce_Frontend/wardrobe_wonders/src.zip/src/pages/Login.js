import React, { useState } from 'react';
import "./Login.css" // Import your CSS file for styling

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    // For example, send a request to your authentication API
    // You can use fetch or axios for this purpose
    
    if (!username || !password) {
      setError('Username and password are required');
      return;
    }

    // Example authentication logic (replace with actual API call)
    // fetch('/api/login', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({ username, password }),
    // })
    //   .then(response => response.json())
    //   .then(data => {
    //     // Handle success (e.g., redirect to dashboard or save token)
    //   })
    //   .catch(err => {
    //     // Handle error (e.g., show error message)
    //     setError('Login failed');
    //   });

    console.log('Logging in with', { username, password });
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit} className="login-form">
        {error && <p className="error-message">{error}</p>}
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="button" className="login-button">Login</button>
      </form>
    </div>
  );
};

export default Login;