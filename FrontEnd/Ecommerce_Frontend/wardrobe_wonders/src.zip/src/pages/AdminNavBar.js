import React from 'react';
import { NavLink } from 'react-router-dom';
import '../Style/AdminNavBar.css';  // Update or create this CSS file for styling

const AdminNavBar = () => {
  return (
    <nav>
      <ul>
        <li>
          <NavLink to="/deleteuser" activeClassName="active-link">Delete User</NavLink>
        </li>
        <li>
          <NavLink to="/addproduct" activeClassName="active-link">Add Product</NavLink>
        </li>
        <li>
          <NavLink to="/updateproduct" activeClassName="active-link">Update Product</NavLink>
        </li>
        <li>
          <NavLink to="/deleteproduct" activeClassName="active-link">Delete Product</NavLink>
        </li>
        <li>
          <NavLink to="/getAllproduct" activeClassName="active-link">View All Product</NavLink>
        </li>
        <li>
          <NavLink to="/getAllproductImages" activeClassName="active-link">View All Product with images</NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default AdminNavBar;